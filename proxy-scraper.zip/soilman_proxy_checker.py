import requests
import threading
import re

entry = """\n
_______  _______  ___  ___      __   __  _______  __    _ 
|       ||       ||   ||   |    |  |_|  ||   _   ||  |  | |
|  _____||   _   ||   ||   |    |       ||  |_|  ||   |_| |
| |_____ |  | |  ||   ||   |    |       ||       ||       |
|_____  ||  |_|  ||   ||   |___ |       ||       ||  _    |
 _____| ||       ||   ||       || ||_|| ||   _   || | |   |
|_______||_______||___||_______||_|   |_||__| |__||_|  |__|


                  authors : @soilman0_0

"""

print(entry)

# Load the proxies from a text file & filter
proxy_pattern = re.compile(r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d+")
proxies = []
with open("proxies.txt") as f:
    for line in f:
        line = line.strip()
        if proxy_pattern.match(line):
            proxies.append(line)

# Create a list to store the live proxies
live_proxies = []

# Define a function to check each proxy
def check_proxy(proxy):
    try:
        proxies = {"http": proxy, "https": proxy}
        response = requests.get("https://www.google.com/", proxies=proxies, timeout=5)
        if response.status_code == 200:
            print(f"{proxy} is live ✅")
            live_proxies.append(proxy)   
    except:
        print(f"{proxy} is dead")

# Create a list of threads
threads = []

# Loop through the proxies list
for proxy in proxies:
    thread = threading.Thread(target=check_proxy, args=(proxy,))
    thread.start()
    threads.append(thread)

# Join all the threads
for thread in threads:
    thread.join()

# Save the live proxies to a text file
with open("live_proxies.txt", "w") as f:
    for proxy in live_proxies:
        f.write(proxy + "\n")
        